#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL__BitScanForward /* Causes code generation in intrin-impl.h */

#include <intrin.h>
