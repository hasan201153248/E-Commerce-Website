#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL___writegsqword // Causes code generation in intrin-impl.h

#include <intrin.h>
