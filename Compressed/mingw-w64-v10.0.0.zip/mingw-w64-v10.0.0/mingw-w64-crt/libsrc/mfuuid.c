
#include <windows.h>
#include <propsys.h>
#include <mediaobj.h>

#include <initguid.h>
#include <mfapi.h>
#include <mfcaptureengine.h>
#include <mfd3d12.h>
#include <mfidl.h>
#include <mfmediacapture.h>
#include <mfreadwrite.h>
